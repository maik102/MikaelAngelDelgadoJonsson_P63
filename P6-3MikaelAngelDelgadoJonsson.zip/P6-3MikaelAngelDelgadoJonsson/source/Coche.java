import javax.swing.JOptionPane;
class Coche{
	private String matricula = null;
	private String marca = "SEAT";
	private String modelo = "ALTEA";
	private String color = "blanco";
	private boolean techo = false;
	private double km = 0;
	private int numPuertas = 3;
	private int numPlazas = 5;
	
	public void setMatricula(String mat){
		matricula = mat;
	}
	
	public String getMatricula(){
		return matricula;
	}
	
	public void setMarca(String m){
		marca = m;
	}
	
	public String getMarca(){
		return marca;
	}
	
	public void setModelo(String mod){
		modelo = mod;
	}
	
	public String getModelo(){
		return modelo;
	}
	
	public void setColor(String c){
		color = c;
	}
	
	public String getColor(){
		return color;
	}
	
	public void setTecho(boolean t){
		techo = t;
	}
	
	public boolean getTecho(){
		return techo;
	}
	
	public void setKM(double k){
		if(k > 0){
			km = k;
		}
	}
	
	public double getKM(){
		return km;
	}
	
	public void setNPuertas(int puerta){
		if(puerta >= 5 && puerta >= 3){
			numPuertas = puerta;
		}
	}
	
	public int getNPuertas(){
		return numPuertas;
	}
	
	public void setNPlazas(int plaza){
		if(plaza <= 7 && plaza > 0){
			numPlazas = plaza;
		}
	}
	
	public int getNPlazas(){
		return numPlazas;
	}
	
	public Coche(){
	}
	
	public Coche(String matricula1){
		matricula = matricula1;
	}
	
	public Coche(int numPuertas1, int numPlazas1){
		numPuertas = numPuertas1;
		numPlazas = numPlazas1;
	}
	
	public Coche(String marca1, String modelo1, String color1){
		marca = marca1; 
		modelo = modelo1;
		color = color1;
	}
	
	void avanzar(double kilom){
		JOptionPane.showMessageDialog(null, "Se tienen " + km + " kilometros, se han anyadido " + kilom);
		km = kilom;
	}
	
	void tunear(){
		km = 0;
		techo = true;
		JOptionPane.showMessageDialog(null, "Se ha puesto el cuentakilometros a 0 y se ha instalado un techo solar");
	}
	
	void tunear(String color1){
		km = 0;
		techo = true;
		color = color1;
		JOptionPane.showMessageDialog(null, "Se ha puesto el cuentakilometros a 0, se ha instalado un techo solar y se le ha cambiado el color a " + color);
	}
	
	void matricular(String matricula2){
		matricula = matricula2;
		JOptionPane.showMessageDialog(null, "Se le ha asignado esta matricula " + matricula);
	}
}
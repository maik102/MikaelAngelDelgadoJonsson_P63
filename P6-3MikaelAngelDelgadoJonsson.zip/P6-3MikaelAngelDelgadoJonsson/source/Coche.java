import javax.swing.JOptionPane;

/**
*Una clase para almacenar los parametros predetermiandos
*o asignados por el usuario de cada coche.
*@version 2.0, 26/01/2018
*@author Mikael Angel Delgado Jonsson
*/
class Coche{
	private String matricula = null;
	private String marca = "SEAT";
	private String modelo = "ALTEA";
	private String color = "blanco";
	private boolean techo = false;
	private double km = 0;
	private int numPuertas = 3;
	private int numPlazas = 5;
	private static int numCoches = 0;
	static final int max_coches = 5;
	
	/**
	*Asigna un string a la variable matricula.
	*@param matricula La matricula del coche.
	*@param mat La matricula que introduce el usuario.
	*/
	public void setMatricula(String mat){
		matricula = mat;
	}
	
	/**
	*Devuelve el valor que tenga la matricula en ese momento.
	*@return El valor de matricula.
	*/
	public String getMatricula(){
		return matricula;
	}
	
	/**
	*Asigna un string a la variable marca.
	*@param marca La marca del coche.
	*@param m La marca que introduce el usuario.
	*/
	public void setMarca(String m){
		marca = m;
	}
	
	/**
	*Devuelve el valor que tenga la marca en ese momento.
	*@return El valor de marca.
	*/
	public String getMarca(){
		return marca;
	}
	
	/**
	*Asigna un string a la variable modelo.
	*@param modelo El modelo del coche.
	*@param mod El modelo que introduce el usuario.
	*/
	public void setModelo(String mod){
		modelo = mod;
	}
	
	/**
	*Devuelve el valor que tenga el modelo en ese momento.
	*@return El valor de modelo.
	*/
	public String getModelo(){
		return modelo;
	}
	
	/**
	*Asigna un string a la variable color.
	*@param color El color del coche.
	*@param c El color que introduce el usuario.
	*/
	public void setColor(String c){
		color = c;
	}
	
	/**
	*Devuelve el valor que tenga el color en ese momento.
	*@return El valor de color.
	*/
	public String getColor(){
		return color;
	}
	
	/**
	*Asigna un boolean a la variable techo.
	*@param techo El techo del coche.
	*@param t El techo que introduce el usuario.
	*/
	public void setTecho(boolean t){
		techo = t;
	}
	
	/**
	*Devuelve el valor que tenga el techo en ese momento.
	*@return El valor de techo.
	*/
	public boolean getTecho(){
		return techo;
	}
	
	/**
	*Asigna un double a la variable km.
	*@param km Los kilometros que tenga el coche.
	*@param k Los kilometros que introduce el usuario.
	*/
	public void setKM(double k){
		if(k > 0){
			km = k;
		}
	}
	
	/**
	*Devuelve el valor que tenga km en ese momento.
	*@return El valor de km.
	*/
	public double getKM(){
		return km;
	}
	
	/**
	*Asigna un int a la variable numPuertas.
	*@param numPuertas Las puertas que tenga el coche.
	*@param puerta Las puertas que introduce el usuario.
	*/
	public void setNPuertas(int puerta){
		if(puerta >= 5 && puerta >= 3){
			numPuertas = puerta;
		}
	}
	
	/**
	*Devuelve el valor que tenga numPuertas en ese momento.
	*@return El valor de numPuertas.
	*/
	public int getNPuertas(){
		return numPuertas;
	}
	
	/**
	*Asigna un int a la variable numPlazas.
	*@param numPlazas Las plazas que tenga el coche.
	*@param plaza Las plazas que introduce el usuario.
	*/
	public void setNPlazas(int plaza){
		if(plaza <= 7 && plaza > 0){
			numPlazas = plaza;
		}
	}
	
	/**
	*Devuelve el valor que tenga numPlazas en ese momento.
	*@return El valor de numPlazas.
	*/
	public int getNPlazas(){
		return numPlazas;
	}
	
	/**
	*Asigna un int a la variable numCoches.
	*@param numCoches Los coches que hay en el almacen.
	*@param coches Los coches que crea el usuario.
	*/
	public void setNCoches(int coches){
		numCoches = coches;
	}
	
	/**
	*Devuelve el valor que tenga numCoches en ese momento.
	*@return El valor de numCoches.
	*/
	public static int getNCoches(){
		return numCoches;
	}
	
	/**
	*Crea un coche e incrementa en 1 numCoches.
	*/
	public Coche(){
		numCoches++;
	}
	
	/**
	*Crea un coche con el valor de matricula en ese momento
	*e incrementa en 1 numCoches.
	*/
	public Coche(String matricula1){
		matricula = matricula1;
		numCoches++;
	}
	
	/**
	*Crea un coche con el valor de numPuertas y numPlazas en ese momento
	*e incrementa en 1 numCoches.
	*/
	public Coche(int numPuertas1, int numPlazas1){
		numPuertas = numPuertas1;
		numPlazas = numPlazas1;
		numCoches++;
	}
	
	/**
	*Crea un coche con el valor de marca, modelo y color en ese momento
	*e incrementa en 1 numCoches.
	*/
	public Coche(String marca1, String modelo1, String color1){
		marca = marca1; 
		modelo = modelo1;
		color = color1;
		numCoches++;
	}
	
	/**
	*Incrementa los kilometros que tenga el coche.
	*/
	public void avanzar(double kilom){
		setKM(kilom);
	}
	
	/**
	*Resetea los kilometros y le implementa un techo solar al coche.
	*/
	public void tunear(){
		setKM(0);
		setTecho(true);
	}
	
	/**
	*Resetea los kilometros, le implementa un techo solar y le cambia el color al coche.
	*/
	public void tunear(String color1){
		setKM(0);
		setTecho(true);
		setColor(color1);
	}
	
	/**
	*Le asigna una matricula al coche.
	*/
	public void matricular(String matricula1){
		setMatricula(matricula1);
	}
}
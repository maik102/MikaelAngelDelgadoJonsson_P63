import javax.swing.JOptionPane;

/**
*Una clase que tiene un menu interactivo para que el usuario pueda
*crear o modificar coches y mostrar sus caracteristicas.
*@version 2.0, 26/01/2018
*@author Mikael Angel Delgado Jonsson
*/
public class Fabrica{
	
	/**
	*Me todo principal de la clase.
	*/
	public static void main(String[] args){
		
		Coche[] almacen = new Coche[Coche.max_coches];
		
		 int menu = 0;
		 int bc;
		 String matBuscada;
		
		do{			
			try{
				menu = Integer.parseInt(JOptionPane.showInputDialog("Selecciona una de las siguientes opciones: \n1.Fabricar coche (conociendo matricula) \n2.Fabricar coche (a partir del numero puertas y el numero de plazas) \n3.Fabricar coche (a partir de la marca, el modelo y el color) \n4.Fabricar coche (cuando no tenemos ningun dato) \n5.Tunear coche (pintandolo de color) \n6.Tunear coche (sin pintarlo) \n7.Avanzar kilometros \n8.Mostrar caracteristicas de un coche \n9.Salir del programa"));
				switch(menu){
							
					case 1: 
						if(Coche.getNCoches() == Coche.max_coches){
							JOptionPane.showMessageDialog(null, "El almacen esta lleno, no se pueden crear mas coches.");
						}else{
							String mat = JOptionPane.showInputDialog("Introduce la matricula: ");
							almacen[Coche.getNCoches()] = new Coche(mat);
							caracteristicas(almacen[Coche.getNCoches() - 1]);
						}
						break;
								
					case 2:
						if(Coche.getNCoches() == Coche.max_coches){
							JOptionPane.showMessageDialog(null, "El almacen esta lleno, no se pueden crear mas coches.");
						}else{
							int pu = Integer.parseInt(JOptionPane.showInputDialog("Introduce el numero de puertas: "));
							int pl = Integer.parseInt(JOptionPane.showInputDialog("Introduce el numero de plazas: "));
							almacen[Coche.getNCoches()] = new Coche(pu, pl);
							almacen[Coche.getNCoches() - 1].matricular(matAleatoria());
							caracteristicas(almacen[Coche.getNCoches() - 1]);
						}
						break;
								
					case 3:
						if(Coche.getNCoches() == Coche.max_coches){
							JOptionPane.showMessageDialog(null, "El almacen esta lleno, no se pueden crear mas coches.");
						}else{
							String ma = JOptionPane.showInputDialog("Introduce la marca del coche: ");
							String mo = JOptionPane.showInputDialog("Introduce el modelo del coche: ");
							String c = JOptionPane.showInputDialog("Introduce el color del coche: ");
							almacen[Coche.getNCoches()] = new Coche(ma, mo, c);
							almacen[Coche.getNCoches() - 1].matricular(matAleatoria());								caracteristicas(almacen[Coche.getNCoches() - 1]);
						}
						break;
								
					case 4: 
						if(Coche.getNCoches() == Coche.max_coches){
							JOptionPane.showMessageDialog(null, "El almacen esta lleno, no se pueden crear mas coches.");
						}else{
							almacen[Coche.getNCoches()] = new Coche();
							almacen[Coche.getNCoches() - 1].matricular(matAleatoria());
							caracteristicas(almacen[Coche.getNCoches() - 1]);
						}
						break;
								
					case 5:
						matBuscada = JOptionPane.showInputDialog("Introduce la matricula del coche deseado: ");
						bc = buscaCoche(matBuscada, almacen);
						if(bc == -1){
							JOptionPane.showMessageDialog(null, "El coche especificado no se encuentra en el garaje");
						}else{
							String colorCoche = JOptionPane.showInputDialog(null, "Introduzca el color que le quiere poner al coche: ");
							almacen[bc].tunear(colorCoche);
							caracteristicas(almacen[bc]);
						}
						break;
								
					case 6:
						matBuscada = JOptionPane.showInputDialog("Introduce la matricula del coche deseado: ");
						bc = buscaCoche(matBuscada, almacen);
						if(bc == -1){
							JOptionPane.showMessageDialog(null, "El coche especificado no se encuentra en el garaje");
						}else{
							almacen[bc].tunear();
							caracteristicas(almacen[bc]);
						}
						break;
								
					case 7:
						matBuscada = JOptionPane.showInputDialog("Introduce la matricula del coche deseado: ");
						bc = buscaCoche(matBuscada, almacen);
						if(bc == -1){
							JOptionPane.showMessageDialog(null, "El coche especificado no se encuentra en el garaje");
						}else{
							double avanzarKM =Double.parseDouble(JOptionPane.showInputDialog("Introduzca los kilometros que quiere avanzar: "));
							almacen[bc].avanzar(avanzarKM);
							caracteristicas(almacen[bc]);
						}
						break;
								
					case 8:
						matBuscada = JOptionPane.showInputDialog("Introduce la matricula del coche deseado: ");
						bc = buscaCoche(matBuscada, almacen);
						if(bc == -1){
							JOptionPane.showMessageDialog(null, "El coche especificado no se encuentra en el garaje");
						}else{
							caracteristicas(almacen[bc]);
						}
						break;
						
					case 9:
						JOptionPane.showMessageDialog(null, "Gracias por utilizar el programa.");
						break;
							
					default:
						JOptionPane.showMessageDialog(null, "El numero introducido no es valido");
						break;
				}
			}catch(Exception e){
				JOptionPane.showMessageDialog(null, "Debes introducir un valor numerico");
			}
		}while(menu != 9);
		
	}
	
	/**
	*Metodo que muestra las caracteristicas de los coches.
	*/
	public static void caracteristicas(Coche c){
		JOptionPane.showMessageDialog(null, "Matricula: " + c.getMatricula() + "\nMarca: " + c.getMarca() + "\nModelo: " + c.getModelo() + "\nColor: " + c.getColor() + "\nTecho Solar: " + c.getTecho() + "\nKilometros: " + c.getKM() + "\nNumero de puertas: " + c.getNPuertas() + "\nNumero de plazas: " + c.getNPlazas());
	}
	
	/**
	*Metodo que genera una matricula aleatoria.
	*@param matRandom Variable que almacena la matricula aleatoria.
	*@return matRandom Devuelve la matricula del coche.
	*/
	public static String matAleatoria(){
		String matRandom = Integer.toString((int)(100000 * Math.random()));
		return matRandom;
	}
	
	/**
	*Metodo que recorre un array buscando un coche por su matricula.
	*@return comprobar Varaibe que devuelve -1 o un numero mayor
	*dependiendo de si ha encontrado o no la matricula.
	*/
	public static int buscaCoche(String mb, Coche[] cBuscado){
		int comprobar = -1;
		for(int j = 0; j < cBuscado.length; j++){
			if(mb.equals(cBuscado[j].getMatricula())){
				comprobar = j;
				return comprobar;
			}
		}
		return comprobar;
	}
}
import javax.swing.JOptionPane;
class Fabrica{
	
	public static void main(String[] args){
		
		Coche car1 = new Coche();
		Coche car2 = new Coche("5678-AG");
		Coche car3 = new Coche("BMW", "850", "gris");
		Coche car4 = new Coche(5, 7);
		
		car1.matricular("1234-DF");
		car3.matricular("9012-HH");
		car4.matricular("3456-XS");
		
		car2.tunear("rojo");
		car4.tunear();
		
		car2.setMarca("FIAT");
		car4.setMarca("VW");
		
		car1.setModelo("TOLEDO");
		car2.setModelo("UNO");
		car3.setModelo("850");
		car4.setModelo("CADDY");
		
		car1.setColor("azul");
		
		car1.setNPuertas(3);
		car2.setNPuertas(3);
		car3.setNPuertas(5);
		
		car1.setNPlazas(5);
		car2.setNPlazas(2);
		car3.setNPlazas(5);
		
		car1.avanzar(200);
		car2.avanzar(300);
		car3.avanzar(400);
		car4.avanzar(500);
		
		Coche[] c = new Coche[4];
		
		c[0] = car1;
		c[1] = car2;
		c[2] = car3;
		c[3] = car4;
		
		caracteristicas(c);
	}
	
	public static void caracteristicas(Coche[] c){
		for(int i = 0; i < c.length; i++){
			JOptionPane.showMessageDialog(null, "Matricula: " + c[i].getMatricula() + "\nMarca: " + c[i].getMarca() + "\nModelo: " + c[i].getModelo() + "\nColor: " + c[i].getColor() + "\nTecho Solar: " + c[i].getTecho() + "\nKilometros: " + c[i].getKM() + "\nNº de puertas: " + c[i].getNPuertas() + "\nNº de plazas: " + c[i].getNPlazas());
		}
	}
}